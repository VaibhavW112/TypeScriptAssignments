//Interface for datatypes
var obj = {
    name: 'krishna',
    age: 23,
    address: 'Pune',
    getName: function () {
        return "Jack Sparrow";
    }
};
console.log(obj.getName());
