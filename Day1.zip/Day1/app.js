"use strict";
exports.__esModule = true;
//Class
// class App{
//     test()
//     {
//         console.warn("Testing....!!")
//     }
// }
// let a1 = new App();
// a1.test();
//DataTypes
//Case --1
// let arr: string[] = ['perry', 'nik', 'chadwick'];
// console.log(arr);
//Case --2
// let arr1 = ['perry', 'nik', 'chadwick',100];
// console.log(arr1);
//Case --3
//let arr2:string[] = ['perry', 'nik', 'chadwick',100];          //Error
//console.log(arr1);
//DataTypes in object
// interface userTypes {
//     name: string,
//     age: number,
//     address: string
// }
// let obj: userTypes = {
//     name: 'krishna',
//     age: 23,
//     address: 'Pune'
// }
// //obj.address = 100; //Type Error
// console.log(obj);
//Any
// let obj: any = {
//     name: 'krishna',
//     age: 23,
//     address: 'Pune'
// }
// obj.name = 100;  //No error 
//Union Types
//  let data : string|number ="Vishal";
//  //data = true;  /Error
//  data = 100; 
//  let data1 : string|number|boolean ="Vishal";
//  data1 = true;  
//  data1 = 100; 
