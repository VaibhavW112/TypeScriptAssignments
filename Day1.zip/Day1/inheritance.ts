class Vehicle {
    modelName: string;
    setName(name: string) {
        this.modelName = name;
    }
}


class FourWheeler extends Vehicle {

getName():string
{
    return this.modelName;
}

}

let fourWheeler = new FourWheeler();

fourWheeler.setName("Creta");

console.log(fourWheeler.getName());
