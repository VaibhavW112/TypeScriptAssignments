function calculation(a, b) {
    return b ? a + b : a;
}
console.log(calculation(20));
