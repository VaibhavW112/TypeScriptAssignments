enum Days {
    mon ="monday",tues ="tuesday",wed = "wednsday",thurs ="thursday"
}

let weekDay:Days = Days.thurs ;

console.log(weekDay);