var Days;
(function (Days) {
    Days["mon"] = "monday";
    Days["tues"] = "tuesday";
    Days["wed"] = "wednsday";
    Days["thurs"] = "thursday";
})(Days || (Days = {}));
var weekDay = Days.thurs;
console.log(weekDay);
