"use strict";
exports.__esModule = true;
var Teacher = /** @class */ (function () {
    function Teacher() {
        this.data = "Teacher Login Page...!!";
    }
    return Teacher;
}());
exports["default"] = Teacher;
