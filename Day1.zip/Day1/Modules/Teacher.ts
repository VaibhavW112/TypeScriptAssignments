export default class Teacher {   
    data = "Teacher Login Page...!!"
}