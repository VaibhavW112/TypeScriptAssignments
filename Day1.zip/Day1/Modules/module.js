"use strict";
exports.__esModule = true;
var Student_1 = require("./Student");
var Teacher_1 = require("./Teacher");
var student = new Student_1["default"]();
console.log(student.data);
var teacher = new Teacher_1["default"]();
console.log(teacher.data);
