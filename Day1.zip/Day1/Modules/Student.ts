export default class Student {   
    data = "Student Login Page...!!"
}