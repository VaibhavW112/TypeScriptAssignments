"use strict";
exports.__esModule = true;
var Student = /** @class */ (function () {
    function Student() {
        this.data = "Student Login Page...!!";
    }
    return Student;
}());
exports["default"] = Student;
