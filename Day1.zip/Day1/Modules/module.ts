import sLogin from './Student'
import tLogin from './Teacher'

let student = new sLogin();

console.log(student.data);

let teacher = new tLogin();

console.log(teacher.data);
