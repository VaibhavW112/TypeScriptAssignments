// class App{
//     employeeName: string ='Jinesh';
//     companyLocation:string ='pune';
//     salary:number = 1000;
//     constructor(name:string){
//         this.employeeName = name;
//     }
//     getDetails():string
//     {
//     return `"Empployee Name : ${this.employeeName} Company Location : ${this.companyLocation}`;
//     }
// }
// let app = new App("Jiten");
//  console.log(app.getDetails());
//Void Return
var App = /** @class */ (function () {
    function App(name) {
        this.employeeName = 'Jinesh';
        this.companyLocation = 'pune';
        this.salary = 1000;
        this.employeeName = name;
    }
    App.prototype.getDetails = function () {
        console.log(this.employeeName + this.companyLocation);
    };
    return App;
}());
var app = new App("Jiten");
app.getDetails();
