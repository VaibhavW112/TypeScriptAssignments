//Interface for datatypes

interface userTypes {
    name: string,
    age: number,
    address: string,
    getName :()=>string
}

let obj5: userTypes = {
    name: 'krishna',
    age: 23,
    address: 'Pune',
    getName :function ()
    {
        return "Jack Sparrow";
    }
}

console.log(obj5.getName())