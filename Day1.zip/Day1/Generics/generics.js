function users(data) {
    return data;
}
console.log(users({ name: 'Vikrant', age: 25 }));
function newUsers(obj) {
    return obj;
}
//console.log(newUsers({ name: 'Vikrant', age: 25 }))
//console.log(newUsers(67));
console.log(newUsers('Pankaj'));
