function calculation(a:number,b?:number):number{
return b?a+b : a;
}

console.log(calculation(20));