// class App{
//     employeeName: string ='Jinesh';
//     companyLocation:string ='pune';
//     salary:number = 1000;

//     constructor(name:string){
//         this.employeeName = name;
//     }

//     getDetails():string
//     {
//     return `"Empployee Name : ${this.employeeName} Company Location : ${this.companyLocation}`;
//     }

// }

// let app = new App("Jiten");

//  console.log(app.getDetails());

           //Void Return

class App{
    employeeName: string ='Jinesh';
    companyLocation:string ='pune';
    salary:number = 1000;

    constructor(name:string){
        this.employeeName = name;
    }

    getDetails():void
    {
    console.log(this.employeeName +"   "+ this.companyLocation );
    }

}

let app = new App("Jiten");

 app.getDetails();